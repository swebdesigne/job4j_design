package ru.job4j.list;

import java.util.List;

public interface ListUsg {
    void output(List<String> list);
}
