package ru.job4j.generics;

public class Student extends Participant {
    public Student(String name, int age) {
        super(name, age);
    }
}
