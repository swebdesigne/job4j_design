public class Trigger {
    public int someLogic() {
        return 1;
    }
}
