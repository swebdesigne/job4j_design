package ru.job4j.io.csvstrategy;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;

public class OutputToFile implements CSVWrite {
    @Override
    public void output(StringBuilder result, String path) {
        Path targetPath = new File(path).toPath();
        boolean needRelative = targetPath.isAbsolute();
        try (FileWriter writer = new FileWriter(path)) {
            if (needRelative) {
                Path sourceRelative = targetPath.relativize(targetPath);
                writer.write(String.valueOf(sourceRelative));
            } else {
                writer.write(String.valueOf(targetPath));
            }
//                writer.write(String.valueOf(result));
            } catch (IOException e) {
                e.printStackTrace();
            }
    }
}
