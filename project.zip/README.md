# job4j_designe

[![Build Status](https://travis-ci.com/swebdesigne/job4j_design.svg?branch=master)](https://travis-ci.com/swebdesigne/job4j_design)
[![codecov](https://codecov.io/gh/swebdesigne/job4j_design/branch/master/graph/badge.svg?token=N9P2KOMUBX)](https://codecov.io/gh/swebdesigne/job4j_design)