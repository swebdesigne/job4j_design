package ru.job4j.io.csvstrategy;

import ru.job4j.io.CSVReader;

public interface CSVWrite {
    public void output(StringBuilder reader, String path);
}
