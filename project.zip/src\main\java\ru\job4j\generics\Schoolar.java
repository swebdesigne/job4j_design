package ru.job4j.generics;

public class Schoolar extends Participant {
    public Schoolar(String name, int age) {
        super(name, age);
    }
}
