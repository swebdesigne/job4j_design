package ru.job4j.io;

import ru.job4j.io.csvstrategy.CSVOutput;
import ru.job4j.io.csvstrategy.OutputToConsole;
import ru.job4j.io.csvstrategy.OutputToFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class CSVReader {
    private final Path path;
    private String delimiter;
    private final String out;
    private final String filter;
    private List<String> columns;
    private StringBuilder result = new StringBuilder();

    public CSVReader(ArgsName argsName) {
        this.out = argsName.get("out");
        this.filter = argsName.get("filter");
        this.path = Path.of(argsName.get("path"));
        this.delimiter = argsName.get("delimiter");
        this.columns = Arrays.asList(filter.split(","));
    }

    public void handle() {
        try (Scanner scanner = new Scanner(path)) {
            String[] header = scanner.nextLine().split(delimiter);
            List<Integer> keys = new ArrayList<>();
            for (int i = 0; i < header.length; i++) {
                if (columns.contains(header[i])) {
                    keys.add(i);
                }
            }
            parseCSVLine(scanner, delimiter, keys);
         } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void display() {
        Map.of("stdout", new CSVOutput(new OutputToConsole()))
                .getOrDefault(out, new CSVOutput(new OutputToFile())).output(result, out);
    }

    private void parseCSVLine(Scanner scanner, String delimiter, List<Integer> keys) {
        result.append(filter.replace(",", ";"));
        while (scanner.hasNext()) {
            int i = 0;
            StringBuilder value = new StringBuilder();
            Scanner line = new Scanner(scanner.nextLine()).useDelimiter(delimiter);
            while (line.hasNextLine()) {
                String tmp = line.next();
                if (keys.contains(i)) {
                    value.append(String.join(System.lineSeparator(), tmp).concat(delimiter));
                }
                i++;
            }
            result.append(System.lineSeparator()).append(value.substring(0, value.length() - 1));
        }
    }

    /**
     * Метод проверят что в параметрах указаны пути до файлов
     * @param log - файл для записи логов
     * @param botAnswers - файл с ответами бота
     */
    private static void validate(String[] args, String log, String botAnswers) throws IOException {
        if (args.length != 2) {
            throw new IllegalArgumentException("Bot folder is null. Usage java -jar dir.jar ROOT_FOLDER.");
        }
        String paramForLog = args[0].split("=")[0];
        String paramForBotAnswer = args[1].split("=")[0];
        if (!paramForLog.equals("-l")) {
            throw new IllegalArgumentException("Attention! The parameter of the file of log have to be `-l`. Please to point such argument into parameters!");
        }
        if (!paramForBotAnswer.equals("-a")) {
            throw new IllegalArgumentException("Attention! The parameter of the file of botAnswers have to be `-a`. Please to point such argument into parameters!");
        }
        if (!Files.exists(Paths.get(botAnswers))) {
            throw new IllegalArgumentException("BotAnswers file not exists.");
        }
    }

    public static void main(String[] args) throws Exception {
//        validate(args);
        ArgsName params = ArgsName.of(args);
        CSVReader csvReader = new CSVReader(params);
        csvReader.handle();
        csvReader.display();
    }
}
